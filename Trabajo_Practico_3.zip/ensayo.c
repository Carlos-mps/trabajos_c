#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
//Carlos Mario Peña Silva 201913784
int main (){
    
    bool terminado = false;
    char string [100];
    printf ("Ingrese una palabra sin espacios\n");
    scanf ("%s", string);
    char* ola;
    ola = &string[0];
    
    int* ptr;
    ptr = (int*)calloc(10, sizeof(int));
    
    int izq = 24;
    
    

    
    for (int i = 0; !terminado ; i++){

    
        if (ola[i] == '\0'){
            terminado = true;
        }
        else{
            printf ("eso es: %c y su valor en hexa es %X\n", ola[i], ola[i]);
            
            
            


            *ptr |= ola[i] << (i * CHAR_BIT);
            
            
            
            
            
            
            
            
            
        
        }
        
    }
    //printf ("\n%X", *ptr);
    
    // | (int)((unsigned char)(ola[i])) << 16 | (int)((unsigned char)(ola[i])) << 16 | (int)((unsigned char)(ola[i])) << 8 | (int)((unsigned char)(ola[i])
    // printf ("%X\n", *ptr);

    
    



   
    for (int i = 0; i < 1 ; i++){
        printf ("%X,%X", *ptr, ptr[i+1]);
         
    }
    
    return 0;


}


